import { Game, Scale, AUTO } from 'phaser';
import { SdkHandler } from './sdk-handler';
import { StartScene } from './scenes/Start';
import { TutorialScene } from './scenes/Tutorial';
import { GameplayScene } from './scenes/Gameplay';
import { GameOverScene } from './scenes/GameOver';

// Game config derived from games/cuu-meo.yaml (BR-13)
const GAME_TITLE = 'Cuu Meo - Bee Dodge';
const GAME_NAME = 'cuu-meo';
const LANE_COUNT = 3;
const LANE_AXIS = 'horizontal';
const MILESTONE_INTERVAL = 10;
const COMBO_PER = 5;
const COMBO_BONUS = 5;

const sdk = new SdkHandler();

const config: Phaser.Types.Core.GameConfig = {
  type: AUTO,
  parent: 'game',
  // BR-05: Responsive — RESIZE mode auto-fits any viewport, keeps state on resize
  scale: {
    mode: Scale.RESIZE,
    width: '100%',
    height: '100%',
  },
  scene: [StartScene, TutorialScene, GameplayScene, GameOverScene],
};

// Fire gameReady when assets are ready and game is interactive
sdk.gameReady();

const game = new Game(config);

// BR-04: obey pause/resume/mute from platform
sdk.onPause(() => {
  game.scene.pause('GameplayScene');
});
sdk.onResume(() => {
  game.scene.resume('GameplayScene');
});

export { GAME_TITLE, GAME_NAME, LANE_COUNT, LANE_AXIS, MILESTONE_INTERVAL, COMBO_PER, COMBO_BONUS, sdk };
