import Phaser from 'phaser';

const LANE_COUNT = 3;

export class GameplayScene extends Phaser.Scene {
  private score = 0;
  private level = 1;
  private streak = 0;
  private bestScore = 0;
  private scoreLabel!: Phaser.GameObjects.Text;
  private levelLabel!: Phaser.GameObjects.Text;

  constructor() {
    super({ key: 'GameplayScene' });
  }

  create() {
    const { width, height } = this.scale;

    this.score = 0;
    this.level = 1;
    this.streak = 0;

    // Score display
    this.scoreLabel = this.add.text(20, 20, '0', {
      fontSize: '24px', color: '#333',
    });
    this.scoreLabel.setData('testid', 'score-label');

    // Level display
    this.levelLabel = this.add.text(width - 100, 20, 'Cấp 1', {
      fontSize: '24px', color: '#333',
    });
    this.levelLabel.setData('testid', 'level-label');

    // Level-up popup (hidden initially)
    const levelPopup = this.add.text(width / 2, 100, '', {
      fontSize: '32px', color: '#E2725B',
    }).setOrigin(0.5);
    levelPopup.setData('testid', 'level-popup');
    levelPopup.setVisible(false);

    // Combo popup
    const comboPopup = this.add.text(width / 2, 150, '', {
      fontSize: '28px', color: '#4A7C59',
    }).setOrigin(0.5);
    comboPopup.setData('testid', 'combo-popup');
    comboPopup.setVisible(false);

    // Record popup
    const recordPopup = this.add.text(width / 2, height / 2, '', {
      fontSize: '36px', color: '#E2725B',
    }).setOrigin(0.5);
    recordPopup.setData('testid', 'record-popup');
    recordPopup.setVisible(false);

    // Input: touch + mouse (BR-05)
    this.input.on('pointerdown', (_pointer: Phaser.Input.Pointer) => {
      // tap to change lane
    });
  }

  update() {
    // Game loop — score increases, bees move, collision check
  }
}
