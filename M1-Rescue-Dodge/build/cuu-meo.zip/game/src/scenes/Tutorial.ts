import Phaser from 'phaser';

export class TutorialScene extends Phaser.Scene {
  constructor() {
    super({ key: 'TutorialScene' });
  }

  create() {
    const { width, height } = this.scale;

    // Tutorial text (3s, auto-advance)
    const tutorialText = this.add.text(width / 2, height / 2, 'Giữ để né ong', {
      fontSize: '28px',
      color: '#333333',
      wordWrap: { width: width * 0.8 },
    }).setOrigin(0.5);

    tutorialText.setData('testid', 'tutorial-text');

    // Auto-advance after 3 seconds
    this.time.delayedCall(3000, () => {
      this.scene.start('GameplayScene');
    });
  }
}
