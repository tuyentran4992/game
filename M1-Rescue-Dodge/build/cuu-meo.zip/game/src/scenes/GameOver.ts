import Phaser from 'phaser';

export class GameOverScene extends Phaser.Scene {
  constructor() {
    super({ key: 'GameOverScene' });
  }

  create(data: { score: number; bestScore: number }) {
    const { width, height } = this.scale;
    const score = data?.score ?? 0;
    const best = data?.bestScore ?? 0;

    // Final score
    const finalScore = this.add.text(width / 2, height / 2 - 80, `Score: ${score}`, {
      fontSize: '36px', color: '#333',
    }).setOrigin(0.5);
    finalScore.setData('testid', 'final-score');

    // Best score
    const bestScore = this.add.text(width / 2, height / 2 - 20, `Best: ${best}`, {
      fontSize: '28px', color: '#666',
    }).setOrigin(0.5);
    bestScore.setData('testid', 'best-score');

    // Retry button
    const retryBtn = this.add.text(width / 2 - 80, height / 2 + 60, 'Chơi lại', {
      fontSize: '24px', color: '#fff', backgroundColor: '#4A7C59',
      padding: { x: 20, y: 10 },
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    retryBtn.setData('testid', 'retry-btn');
    retryBtn.on('pointerdown', () => {
      this.scene.start('GameplayScene');
    });

    // Continue button (rewarded ad)
    const continueBtn = this.add.text(width / 2 + 80, height / 2 + 60, 'Tiếp tục (xem ad)', {
      fontSize: '24px', color: '#fff', backgroundColor: '#E2725B',
      padding: { x: 20, y: 10 },
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    continueBtn.setData('testid', 'continue-btn');
    continueBtn.on('pointerdown', () => {
      // Request rewarded ad (BR-10)
    });
  }
}
