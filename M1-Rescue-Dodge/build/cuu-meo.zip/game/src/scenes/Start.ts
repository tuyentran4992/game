import Phaser from 'phaser';

export class StartScene extends Phaser.Scene {
  constructor() {
    super({ key: 'StartScene' });
  }

  create() {
    const { width, height } = this.scale;

    // Title text
    this.add.text(width / 2, height / 2 - 60, 'CỨU MÈO', {
      fontSize: '48px',
      color: '#4A7C59',
    }).setOrigin(0.5);

    // Play button (data-testid required)
    const playBtn = this.add.text(width / 2, height / 2 + 40, 'Chơi', {
      fontSize: '32px',
      color: '#ffffff',
      backgroundColor: '#4A7C59',
      padding: { x: 40, y: 20 },
    })
      .setOrigin(0.5)
      .setInteractive({ useHandCursor: true });

    // data-testid for Playwright/E2E
    playBtn.setData('testid', 'start-btn');
    // Also set as DOM attribute via Phaser DOM element approach
    this.add.dom ? null : null;

    playBtn.on('pointerdown', () => {
      this.scene.start('TutorialScene');
    });

    // BR-05: handle resize
    this.scale.on('resize', (gameSize: Phaser.Structs.Size) => {
      // Re-center elements on resize — keeps state
    });
  }
}
